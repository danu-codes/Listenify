import React, { useState } from "react";
import "./Explore.css";
import { Navbar } from "../../components/Navbar/Navbar";
import { stories } from "../../data/stories";

export const Explore = () => {

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const categories = [
    "Horror",
    "Romance",
    "Sci-Fi",
    "Motivation",
    "Kids",
    "Podcasts"
  ];

  // 🔍 SEARCH FILTER
  let filteredStories = stories.filter((story) =>
    story.title.toLowerCase().includes(search.toLowerCase())
  );

  // 🎯 FILTER SYSTEM
  if (filter === "popular") {
    filteredStories.sort((a, b) => b.popularity - a.popularity);
  }

  if (filter === "newest") {
    filteredStories.sort(
      (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
    );
  }

  if (filter === "duration") {
    filteredStories.sort((a, b) => a.duration - b.duration);
  }

  return (
    <>
      <Navbar />

      <div className="explore-container">

        {/* TITLE */}
        <h1 className="explore-title">
          Discover Stories 🔍
        </h1>

        {/* SEARCH */}
        <div className="search-box">
          <input
            type="text"
            placeholder="Find any story instantly..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button>🔍</button>
        </div>

        {/* FILTERS */}
        <div className="filter-box">
          <button onClick={() => setFilter("all")}>All</button>
          <button onClick={() => setFilter("popular")}>Popular</button>
          <button onClick={() => setFilter("newest")}>Newest</button>
          <button onClick={() => setFilter("duration")}>Duration</button>
        </div>

        {/* CATEGORY GRID */}
        <h2 className="section-title">Browse Categories</h2>

        <div className="category-grid">
          {categories.map((cat, index) => (
            <div key={index} className="category-card">
              {cat}
            </div>
          ))}
        </div>

        {/* STORY RESULTS */}
        <h2 className="section-title">Stories</h2>

        <div className="category-grid">
          {filteredStories.map((story) => (
            <div key={story.id} className="category-card">

              <h3>{story.title}</h3>
              <p>{story.category}</p>
              <small>{story.duration} min</small>

            </div>
          ))}
        </div>

      </div>
    </>
  );
};