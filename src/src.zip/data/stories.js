export const stories = [
  {
    id: 1,
    title: "Haunted Forest Whisper",
    category: "Horror",
    duration: 12,
    popularity: 95,
    createdAt: "2026-01-10",
    description: "A scary story inside a cursed forest.",

    // 🎧 AUDIO FILE
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",

    // 🖼️ IMAGE
    image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee"
  },
  {
    id: 2,
    title: "Love in Paris Night",
    category: "Romance",
    duration: 8,
    popularity: 88,
    createdAt: "2026-01-12",
    description: "A romantic journey in Paris.",

    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    image: "https://images.unsplash.com/photo-1504198453319-5ce911bafcde"
  },
  {
    id: 3,
    title: "Journey to Mars",
    category: "Sci-Fi",
    duration: 15,
    popularity: 99,
    createdAt: "2026-01-18",
    description: "Human mission to Mars survival story.",

    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa"
  },
  {
    id: 4,
    title: "Morning Motivation Power",
    category: "Motivation",
    duration: 5,
    popularity: 80,
    createdAt: "2026-01-20",
    description: "Start your day with energy.",

    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    image: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429"
  }
];