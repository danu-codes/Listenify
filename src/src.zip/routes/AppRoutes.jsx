import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Home } from "../pages/Home/Home";
import { Explore } from "../pages/Explore/Explore";
import { Upload } from "../pages/Upload/Upload";
import Auth from "../pages/Auth/Auth";
import { AudioPlayer } from "../pages/Home/components/AudioPlayer/AudioPlayer";

export const AppRoutes = () => {
    const [currentStory, setCurrentStory] = useState(null);
    return (<>

        <Routes>
            <Route
                path="/"
                element={<Home setCurrentStory={setCurrentStory} />}
            />

            <Route
                path="/explore"
                element={<Explore setCurrentStory={setCurrentStory} />}
            />

            <Route path="/upload" element={<Upload />} />
            <Route path="/auth" element={<Auth />} />

        </Routes>

        GLOBAL PLAYER
        <AudioPlayer currentStory={currentStory} />
    </>

    );

};
